package logic;

import java.util.ArrayList;

public class Catatan {
    private ArrayList<String> daftarCatatan;

    public Catatan() {
        daftarCatatan = new ArrayList<>();
    }

    public void tambahCatatan(String isi) {
        daftarCatatan.add(isi);
    }

    public void tampilkanCatatan() {
        if (daftarCatatan.isEmpty()) {
            System.out.println("Belum ada catatan.");
        } else {
            System.out.println("Daftar Catatan:");
            for (int i = 0; i < daftarCatatan.size(); i++) {
                System.out.println((i + 1) + ". " + daftarCatatan.get(i));
            }
        }
    }
}
