import data.Pengguna;
import logic.Catatan;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Pengguna user = new Pengguna("Reno", "abc123");
        Catatan catatanHarian = new Catatan();

        System.out.println("=== Aplikasi Catatan Harian ===");
        System.out.print("Masukkan Nama: ");
        String nama = input.nextLine();
        System.out.print("Masukkan Password: ");
        String password = input.nextLine();

        if (user.validasi(nama, password)) {
            System.out.println("\nLogin Berhasil! Selamat datang, " + user.getNama());
            System.out.print("Masukkan catatan hari ini: ");
            String catatan = input.nextLine();
            catatanHarian.tambahCatatan(catatan);
            System.out.println("\nCatatan berhasil disimpan!\n");
            catatanHarian.tampilkanCatatan();
        } else {
            System.out.println("\nLogin gagal! Identitas tidak valid.");
        }

        input.close();
    }
}
