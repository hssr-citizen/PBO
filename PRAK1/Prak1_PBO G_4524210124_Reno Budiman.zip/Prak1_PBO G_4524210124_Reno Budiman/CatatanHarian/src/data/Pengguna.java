package data;

public class Pengguna {
    private String nama;
    private String password;

    // Constructor tanpa parameter
    public Pengguna() {
        this.nama = "Reno";
        this.password = "12345";
    }

    // Constructor dengan parameter
    public Pengguna(String nama, String password) {
        this.nama = nama;
        this.password = password;
    }

    // Setter
    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    // Getter
    public String getNama() {
        return nama;
    }

    public String getPassword() {
        return password;
    }

    // Method validasi identitas pengguna
    public boolean validasi(String inputNama, String inputPassword) {
        return this.nama.equals(inputNama) && this.password.equals(inputPassword);
    }
}
